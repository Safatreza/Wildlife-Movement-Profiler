if __name__ == "__main__":
    print("Welcome to the Wildlife Movement Profiler!") 